/*!
 * Phylogeny Explorer
 *
 * @summary
 * @author John Ropas
 * @since 16/11/2016
 *
 * Copyright(c) 2016 Phylogeny Explorer
 */

import Tree from './Tree';

export default Tree;
